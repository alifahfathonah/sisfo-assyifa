<?php
use yii\bootstrap4\Breadcrumbs;
use yii\bootstrap4\Alert;

/* (C) Copyright 2019 Heru Arief Wijaya (http://belajararief.com/) untuk Indonesia.*/
?>

<!-- Begin Page Content -->
<div class="container-fluid">
    
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">

        <?php if (isset($this->blocks['content-header'])) { ?>
            <h1 class="h3 mb-0 text-gray-800"><?= $this->blocks['content-header'] ?></h1>
        <?php } else { ?>
            <h1 class="h3 mb-0 text-gray-800">
                <?php
                if ($this->title !== null) {
                    echo \yii\helpers\Html::encode($this->title);
                } else {
                    echo \yii\helpers\Inflector::camel2words(
                        \yii\helpers\Inflector::id2camel($this->context->module->id)
                    );
                    echo ($this->context->module->id !== \Yii::$app->id) ? '<small>Module</small>' : '';
                } ?>
            </h1>
        <?php } ?>

        <?=
        Breadcrumbs::widget(
            [
                'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
            ]
        ) ?>
    </div>    
    <!-- Content Row -->
    <div class="row">
        <div class="col-md-12">
            <?= Yii::$app->getSession()->getAllFlashes() ? Alert::widget() : '' ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?= $content ?>
        </div>
    </div>
</div>
<!-- /.container-fluid -->
